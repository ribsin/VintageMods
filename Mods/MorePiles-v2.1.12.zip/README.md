# More Piles
## [Issues](https://github.com/Craluminum2413/Craluminum-Mods/issues)/ [VSModDB](https://mods.vintagestory.at/morepiles)
Adds piles using GroundStorable collectible behavior