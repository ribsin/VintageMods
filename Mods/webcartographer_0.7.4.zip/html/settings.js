var settings = {
    title: "My VS Server",
    titleBarName: "My VS",
    titleBarCommunity: "My Community",
    siteUrl: "https://example.com",
    updateText : "Last updated on ",
    lastUpdated : "2025-04-22_12-00-00"
}