=========================================================================
Presented by "CONQUEST OF BLOCKS" - Multiplayer server for Vintage Story.
=========================================================================

Website: www.vintagestory.online
Discord: discord.gg/jbVQTd3h77

Mod description:
In the vanilla game, traders can mostly be found as lone wolves somewhere in the wild. 
With this mod, traders will more often hang out together in small camps. Single traders will 
still be available, but less often.


This version of our server mod is free to use on any other multiplayer server.
Your clients do not need to download this mod. It's server side only.


HOW TO MODIFY:
==============
The mod will generate a "TraderCamps.json" in your ModConfig folder.

"TraderCampSetup":

1 - (medium density, claimed) - default value
2 - (medium density, unclaimed)
3 - (high density, claimed)
4 - (high density, unclaimed)
5 - (low density, claimed) - recommended for hardcore survival
6 - (low density, unclaimed)


"WastedCampSetup":

0 - (no wasted camps)
1 - (medium density, unclaimed) - default value
2 - (high density, unclaimed)
3 - (low density, unclaimed)


"LoneTraderSetup":

0 - (no lone traders)
1 - (rare, claimed) - default value
2 - (rare, unclaimed)
3 - (common, claimed)
4 - (common, unclaimed)


Notes:
Will only apply to traders in newly generated chunks.
Raising the chance of Lone Traders to appear will decrease the chance of camps.