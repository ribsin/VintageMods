# StoneQuarry

### Links: [ModDB](https://mods.vintagestory.at/stonequarry), [Forum](https://www.vintagestory.at/forums/topic/6042-stone-quarry/)

<hr>

This is the new version (fork) of [Quarry Works!](https://github.com/Wraith-Hunter/The-Works/tree/main/QuarryWorks) for 1.15+
