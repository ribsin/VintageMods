# Rustbound Magic XSkills Compatibility

Make Rustbound Magic[1] compatible with XSkills[2]: killing drones / sentries / ravagers / titans / colossus now gives you combat XP.

[1]: https://mods.vintagestory.at/show/mod/6716
[2]: https://mods.vintagestory.at/show/mod/247
