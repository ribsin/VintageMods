# Tailor's Delight

"Craft and decorate with cloth, thread, leather and hide."

This Vintage Story mod adds items and blocks related to the tailor
trade, and for crafting and decorating with cloth, leather and hide.

## Tweaks

* Many recipes now need either needles, awls or accessories to craft.
* More items can be stored on the ground or in display cases.
* Some vanilla clothing recipes can be crafted
* Some vanilla warm clothing items have their body warmth slightly boosted

## New Materials and Accessories

* Buttons and clasps made from a variety of materials
* Craft checkered cloth
* Adds a way to preserve hides with salt
* Craft scraped and aged hide
* Adds darker leather colors
* Dye twine into colored threads
* Craft cloth, hide and leather panels

## Tools of the Trade

### Stitching Awls

A tool made from bone or metal to bore holes in fabric or leather.

### Needles

Used in sewing clothes and to craft sewing kits for more advanced crafting.

### Rulers

Made from wood or metal. Also double as a tailor-class specific weapon.

### Wooden spindle

A tool to spin fibers more efficiently into twine.

## Hide, Leather and Cloth Panels

Come in different colors and shapes and can be attached to any flat surface.

## Table cloth

Can be put on tables or any other full block, flat surface.


We hope you enjoy our work.

~Phiwa & Tels

# Download

* The mod from [Official Vintage Story ModDB](https://mods.vintagestory.at/tailorsdelight)
* You also need to install [Expanded Matter](https://mods.vintagestory.at/em)
* The source code can be found on [Gitlab](https://gitlab.com/codesmiths/vs_tailors_delight/-/releases)

# Installation

This mod should work in existing worlds. If in doubt, please create a new world.

  <u>**Make a backup of your savegame and world before trying this mod!**</u>

If you would like to translate this mod into other languages, please [contact us](https://gitlab.com/codesmiths/vs_bricklayers/-/wikis/Contact).

# Signature key

All our releases are signed using PGP (GnuPG) and their integrity can be verified by using the public key as published
[on the wiki](https://gitlab.com/codesmiths/vs_bricklayers/-/wikis/Signing-key).

